export const environment = {
  production: false,
    firebase: {
    apiKey: "AIzaSyDu8sWgZOhMa7VBaWD2KcPn8JUa5R3bt50",
    authDomain: "clientspace-mobile.firebaseapp.com",
    databaseURL: "https://clientspace-mobile.firebaseio.com",
    projectId: "clientspace-mobile",
    storageBucket: "clientspace-mobile.appspot.com",
    messagingSenderId: "535177797216"
  }

};